# CS-174
This is CS 174.
http://web.cs.ucla.edu/~dt/courses/CS174A/animations/assignment2-best-16s/

magicavoxel https://www.25xt.com/article/56599.html
import magicavoxel into blender https://www.youtube.com/watch?v=c8xocTFhvaw
